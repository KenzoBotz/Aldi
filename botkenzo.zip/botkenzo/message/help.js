exports.menu = (prefix, i) => {
    return `*[ KENZO BOT ]*
❏ *wa.me/6289670255986*
❏ *YT : KenzoBotz*

*INFO*
❏ *cekprefix*
❏ *${prefix}stats*
❏ *${prefix}limit*
❏ *${prefix}balance*
❏ *${prefix}runtime*
❏ *${prefix}speed*
❏ *${prefix}owner*
❏ *${prefix}donasi*


*Coverter / Tools*
❏ *${prefix}sticker*
❏ *${prefix}swm*
❏ *${prefix}take*
❏ *${prefix}toimg*
❏ *${prefix}attp text*
❏ *${prefix}tinyurl url*
❏ *${prefix}nuliskiri text*
❏ *${prefix}nuliskanan text*
❏ *${prefix}foliokiri text
❏ *${prefix}foliokanan text
❏ *${prefix}translate kodebahasa [reply pesan/text]

*Downloader*
❏ *${prefix}ytmp4 url*
❏ *${prefix}ytmp3 url*
❏ *${prefix}igdl url*
❏ *${prefix}fbdl url*
❏ *${prefix}tiktok url*
❏ *${prefix}yts query*
❏ *${prefix}play query*
❏ *${prefix}playmp4 query*

*Stalker*
❏ *${prefix}igstalk username*
❏ *${prefix}ghstalk username*

*Text Marker*
❏ *${prefix}blackpink text*
❏ *${prefix}tahta text*
❏ *${prefix}neon text*
❏ *${prefix}glitch text1|text2*
❏ *${prefix}thundername text*
❏ *${prefix}pornhub text1|text2*

*Baileys*
❏ *${prefix}tagme*
❏ *${prefix}kontak nomor|nama*
❏ *${prefix}hidetag*
❏ *${prefix}jadian*
❏ *${prefix}ganteng*
❏ *${prefix}cantik*

*Premium*
❏ *${prefix}addprem @tag*
❏ *${prefix}delprem @tag*
❏ *${prefix}cekprem*
❏ *${prefix}listprem*

*Ban*
❏ *${prefix}ban @tag*
❏ *${prefix}unban @tag*
❏ *${prefix}listban*

*Game*
❏ *${prefix}topbalance*
❏ *${prefix}buylimit*
❏ *${prefix}buyglimit*
❏ *${prefix}tictactoe @tag*
❏ *${prefix}tebakgambar*
❏ *${prefix}family100*

*VVIBU*
❏ *${prefix}waifu*
❏ *${prefix}loli*
❏ *${prefix}nekonime*
❏ *${prefix}megumin*
❏ *${prefix}sagiri*
❏ *${prefix}shinobu*

*Random*
❏ *${prefix}apakah*
❏ *${prefix}bisakah*
❏ *${prefix}kapankah*
❏ *${prefix}hobby*
❏ *${prefix}rate*
❏ *${prefix}cekbapak*
❏ *${prefix}seberapagay*
❏ *${prefix}truth*
❏ *${prefix}dare*

*Group*
❏ *${prefix}afk*
❏ *${prefix}infogrup*
❏ *${prefix}chatinfo*
❏ *${prefix}add 628xx*
❏ *${prefix}kick @tag*
❏ *${prefix}promote @tag*
❏ *${prefix}demote @tag*
❏ *${prefix}linkgc*
❏ *${prefix}leave*
❏ *${prefix}setdesc*
❏ *${prefix}setgrupname*
❏ *${prefix}setppgrup*
❏ *${prefix}opengrup*
❏ *${prefix}closegrup*
❏ *${prefix}join*
❏ *${prefix}tagall*
❏ *${prefix}mute*
❏ *${prefix}unmute*

*Enable / Disable*
❏ *${prefix}antilink*
❏ *${prefix}welcome*
❏ *${prefix}left*
❏ *${prefix}antibadword*
❏ *${prefix}listbadword*
❏ *${prefix}addbadword*
❏ *${prefix}delbadword*

*Owner*
>
$
❏ *${prefix}setprefix*
❏ *${prefix}bc
❏ *${prefix}clearall
❏ *${prefix}exif nama|author

Note :
*No Bandingkan Kan Bot*
*Mau Sewa Bot?*
*Ketik [ IKLAN ]*


}
